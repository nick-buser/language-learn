---
name: aburaya-design
description: Use this skill to generate well-branded interfaces and assets for Aburaya (油屋), either for production or throwaway prototypes/mocks/etc. Aburaya is a design language inspired by the Spirited Away bath-house and the lantern-lit streets of Jiufen — lacquer-red, matte gold, warm-sumi-vs-cool-night blacks, all-serif type, glow-as-depth, and Ma (generous space). Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files —
especially `colors_and_type.css` (the token source of truth), `preview/` (the design-system
cards), and `ui_kits/aburaya/` (a working bath-house concierge app you can lift components from).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and
create static HTML files for the user to view. If working on production code, copy the assets
and read the rules here to become an expert in designing with this brand.

Core rules to hold (full detail in README.md):
- **Dark (night) mode is canonical**; light (day) mode is a true daytime counterpart, not a washed-out inversion.
- **Depth = light, not shadow, at night** (amber glow bloom + gilt keyline); warm-brown shadows by day.
- Red is a **surface/signal, never body text**; gold is **matte and rare**, for emphasis/labels only.
- All-serif type: **Fraunces** display (h3+ only), **Newsreader** body; **Noto Serif/Sans JP** for CJK. Consume **semantic tokens only**, never raw pigments.
- Motion is **weightless and never bounces**; prefer transform-only entrances so content never freezes hidden.
- Lean into **verticality, asymmetric balance, and Ma** (generous space). Avoid the kitsch guardrails.

If the user invokes this skill without any other guidance, ask them what they want to build or
design, ask a few focused questions, and act as an expert designer who outputs HTML artifacts
_or_ production code, depending on the need.
