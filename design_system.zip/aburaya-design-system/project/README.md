# Aburaya (油屋) — Design System

A design language inspired by the bath-house of *Spirited Away* and the lantern-lit
hillside streets of Jiufen. Codename **Aburaya** (油屋), after the bath-house itself.

Aburaya lives in the tension between two moments the bath-house is most beautiful in:
the **daylight backdrop** (high sky-blue, soft clouds, painted tile roofs in sun) and
the **night** (a deep blue-black sky, the building glowing from within on red, gold and
lantern-amber light). **Dark mode is the primary, canonical expression**; light mode is
its fully-considered daytime counterpart — never a washed-out inversion.

Four ideas hold it together:
- **Gouache, not gloss.** Dense, matte, slightly chalky pigment — opaque watercolor in flat washes. Nothing glassy, neon, or chrome. Even gold is matte *leaf*.
- **Lantern glow is the light source.** Warmth radiates from red and gold elements; in the dark, *light* (not shadow) signals depth and focus.
- **Traditional grandeur, restrained.** Opulent and ceremonial — lacquer, gilt, banners, tiered eaves — but disciplined. Reverence, not costume. (See Guardrails.)
- **Ma (間).** Meaningful interval — generous negative space and calm pacing are load-bearing.

> This is a brief-driven system. There was no existing codebase or Figma file to import;
> every token here was authored directly from the *Aburaya Design System Brief* (the
> source hand-off document). Treat the brief as the canonical spec; this folder is its build.

---

## Sources
- **Aburaya Design System Brief** — the originating hand-off document (provided in chat). Contains the full philosophy, the raw pigment table, both semantic-token maps, the type pairings + scale, motion/space tokens, component sketches, and the kitsch guardrails. All values here are lifted from it.
- No GitHub repo, Figma file, codebase, or slide deck was attached. If one exists, link it here so future readers can cross-reference.

---

## CONTENT FUNDAMENTALS — how Aburaya writes

**Voice:** unhurried, warm, quietly ceremonial but genuinely welcoming — *a gracious host
in a grand old place.* Never frantic, never shouty, never cute-for-cute's-sake.

- **Register shifts with the moment.** Functional copy (buttons, fields, errors) is plain
  and clear. Empty states, onboarding, and celebratory moments turn a little more lyrical.
  - Functional: "Sign & reserve", "Hour of arrival", "Draw a new bath".
  - Lyrical: "Sign your name to the contract and the lanterns will light.", "A gracious welcome awaits — take your time.", "Ma — meaningful interval. This wing is left intentionally quiet."
- **Person.** Address the guest as **you**; the house refers to itself sparingly as *we*
  ("A gracious welcome awaits"). The product is a *place* with a host, not a dashboard.
- **Casing.** Sentence case in prose and buttons. **Labels** (eyebrows, field labels) are
  UPPERCASE with +0.08em tracking — the "carved/stamped sign" feel, and a natural home for gold.
- **Metaphor is consistent, never winking.** Real bath-house vocabulary does the work:
  baths, contracts, lanterns, tokens, soak, stores, ledger, guests. Avoid generic SaaS nouns
  where a bath-house noun fits.
- **No emoji.** Glyphs of meaning are real **CJK characters** (湯, 油屋, 間), set in the CJK
  type, not decoration. Numerals are lining/tabular in data.
- **Vibe:** lantern-lit, leisurely, reverent-but-warm. One strong line, lots of air.

---

## VISUAL FOUNDATIONS

**Color.** Red, black, and gold are the stars. Red (`vermilion-500`) is lacquer — the
brand's voice, used as **surface and signal, never body text**. Gold (`gold-400/600`) is
matte gilt — emphasis and labels only. Two distinct "blacks": warm **sumi** ink (timber,
frames, ornament) held apart from cool **night** blue-black (the sky canvas) — that
separation is what makes the night feel like a *place*. **Amber** sits on top as the
emissive *glow*, used sparingly. Pigments are muted/earthy gouache; whites are creamy
rice-paper (`paper-50`), never `#FFFFFF` — the only near-white is `cloud` (`#FBFDFE`).
All values + both semantic-mode maps live in **`colors_and_type.css`**.

**Type.** All-serif, the most on-theme pairing: **Fraunces** (variable, high optical size,
slight `SOFT`) for display/signage at **h3 and above only**; **Newsreader** for body & UI.
Dense/dashboard products may swap body to **Hanken Grotesk** (warm humanist sans). CJK
companion is **Noto Serif/Sans JP** (shared brush DNA). Mono is **Spline Sans Mono**.
Scale is 16px base, major-third → perfect-fourth at display. Hierarchy is carried by size,
weight, and color — there is no sans/serif contrast to lean on, so discipline is required.
Body line-height is generous (1.65); display is tight (1.05–1.12) and grand. One display
line per view, ideally.

**Spacing & layout.** 8px base with a deliberately generous large end for *ma*
(`space-4xl` 96, `space-5xl` 128). Lean into **verticality** (tall banners, lantern
strings, vertical CJK signage, tiered sections) and **asymmetric, ukiyo-e balance**
(off-center focal points, intentional empty quadrants, one grand anchor). Frame every view
architecturally: a **roofline** (header band of timber/sumi), **pillars** (side rail),
a **floor** (footer). Foreground lacquer panels sit over the deep night/sky canvas so the
user feels they are *looking into* the bath-house. Distant elements desaturate toward the
sky color (atmospheric depth).

**Backgrounds.** No photography in chrome. The canvas is a soft vertical/radial wash —
sky→cloud by day, a faint warmer center by night. A very low-opacity **gouache grain**
(SVG `feTurbulence`, ~3% opacity) sits over large surfaces to defeat the flat-digital look.
A barely-there kumiko/lattice may serve as low-contrast texture. No bluish-purple gradients.

**The depth principle (the single most evocative rule).** *In daylight, things cast
shadow; at night, things give light.*
- **Light mode:** soft **warm-brown** shadows tinted toward `timber-800` (never neutral
  gray), low opacity — timber casting shade in afternoon sun.
- **Dark mode:** drop shadows are all but abandoned. Elevation = a slightly warmer/lighter
  surface + a faint **amber glow bloom** + a thin **gilt keyline**. Raised = *catching
  lantern light*. Tokens: `--elev-1/2/3`, `--glow-soft/raised/focus/hover-bloom`.

**Borders & corners.** Hairline (`border/hairline`) for ordinary separation; a reserved
1px **gilt keyline** (often inset 1–2px) marks ceremony/emphasis/elevation — the gold leaf
trimming a lacquer tray. *If everything is gilt, nothing is.* Radii are **restrained**
(default `radius-sm` 4, cards `radius-md` 8, modals `radius-lg` 12, sharp 0 for banners,
full only for lantern dots/avatars) — the enemy is bubbly modern softness.

**Cards** are **lacquer trays**: flat matte fill (`bg/surface-raised`), restrained radius,
generous internal padding (`space-lg`+), an inset gilt keyline on emphasis, and elevation
via glow (dark) or warm shadow (light). Not heavy borders.

**Motion.** Restrained, elegant, weightless — *it never bounces.* Spring/`back`/`elastic`
are off-theme. **Drift & settle**: elements float in (small translate + fade) and
decelerate to rest (`ease-enter`, no overshoot). **Light is the feedback**: hover raises a
warm amber halo, press deepens it. **Procession**: lists reveal with a gentle ~40–60ms
stagger. **Ambient life**: very slow (18–40s) low-contrast loops — drifting clouds by day,
faint rising haze + imperceptible lantern flicker by night; never pulls focus. Easings:
`ease-drift` (default), `ease-enter` (arrivals), `ease-exit` (departures). Durations
80 → 640ms (a touch longer than typical web — that's the leisure).
*Implementation note:* gate entrances so the visible state is the base and prefer
transform-only keyframes — never animate `opacity` from 0 as the only path to visible, or
content can freeze hidden under reduced-motion, print, or capture.

**Hover / press / focus.**
- *Hover:* amber glow bloom (and a brightening toward `vermilion-300` on the primary). Not a hard color flip.
- *Press:* glow deepens; a ~0.5px settle, never a springy shrink.
- *Focus:* a warm **lantern-glow ring** that blooms on (`--glow-focus`), with a **static
  non-glow outline fallback** for `prefers-reduced-motion` / high-contrast. Never rely on
  glow alone to convey state — it always accompanies a shape, label, or border change.

**Transparency & blur.** Used sparingly: warm-tinted scrims behind modals (a dark/amber
wash, not neutral); faint amber color-mix washes behind ghost buttons. No frosted-glass
everywhere; the material is matte pigment, not glass.

**Imagery vibe (when present).** Warm, painterly, gouache — opaque flat washes, slightly
chalky. Hand-painted/brushy edges live in **illustration only** (empty-state art,
decorative banners, dividers-as-illustration) — functional UI stays crisp and legible.

**Accessibility.** Red is never text. Carry text in warm off-white or gold. All pairings
target **WCAG AA** (4.5:1 body, 3:1 large); the warm off-whites and `gold-400`/`gold-600`
are chosen to pass — re-check any new pairing. Provide the non-glow focus fallback.

---

## ICONOGRAPHY

The brief specifies **line icons, medium weight, rounded joins — calm and even**, with the
option of a warm glow on active state rather than only a color change. Functional icons stay
simple and instantly legible; decorative/brand marks may borrow **mon** (family-crest)
geometry — radially symmetric, contained in a circle.

- **No bespoke icon font or SVG set existed** (no codebase). The closest CDN match to the
  spec is **[Lucide](https://lucide.dev)** — line icons, rounded joins, ~2px stroke,
  consistent and legible. **The UI kit uses Lucide via CDN** (`lucide@0.460.0`), rendered
  through the `<Icon name>` component at stroke-width ~1.75. **⚠️ This is a substitution** —
  if Aburaya commissions a bespoke crest-geometry icon set, drop it into `assets/icons/`
  and repoint `<Icon>`.
- **No emoji**, ever. Meaningful glyphs are real **CJK characters** (湯, 油屋, 間, the bath
  names 薬湯/檜蒸/灯湯…) set in Noto Serif/Sans JP — used as crest/seal marks, badges, and
  vertical signage, not as decoration.
- **Brand marks** in this build are typographic: the 湯 seal in the side rail and the 油屋
  noren wordmark. There is no raster logo file yet — see Caveats.
- Active/selected icons take a faint amber wash + gilt keyline rather than only a color flip.

---

## VISUAL ASSETS
`assets/` — brand/imagery assets. Currently this system ships **no raster logos or
illustrations** (none were provided, and the guardrails forbid auto-generating brush/SVG
art that would read as kitsch). The brand marks are typographic (湯 seal, 油屋 noren).
*Provide real logo/illustration files and they belong here.*

---

## INDEX — what's in this folder

| Path | What it is |
|---|---|
| `README.md` | This file — context, content + visual foundations, iconography, index |
| `SKILL.md` | Agent-Skill front-matter so this system works in Claude Code |
| `colors_and_type.css` | **Source of truth.** Raw pigments → semantic tokens (dark + light) → type system → space/radii/motion/elevation primitives |
| `fonts.css` | Webfont loading (Google Fonts: Fraunces, Newsreader, Hanken Grotesk, Spline Sans Mono, Noto Serif/Sans JP) |
| `preview/` | Design-System cards (~700px): colors, type, spacing, radii, elevation, motion, components. `card.css` is their shared base |
| `ui_kits/aburaya/` | The UI kit — a bath-house concierge web app in both modes. See its own `README.md` |
| `assets/` | Brand/imagery assets (logos, illustrations) — currently empty; see Caveats |
| `screenshots/` | Working screenshots captured during the build (not a deliverable) |

### Design-System cards (in `preview/`)
- **Colors:** `colors-red-gold`, `colors-neutrals`, `colors-semantic-dark`, `colors-semantic-light`
- **Type:** `type-display`, `type-body`, `type-scale`, `type-cjk`
- **Spacing:** `spacing-scale`, `radii`, `elevation` (the depth principle), `motion`
- **Components:** `components-buttons`, `components-inputs`, `components-card`, `components-badges`, `components-noren`

---

## GUARDRAILS — keeping it out of kitsch
- **Do** keep gold matte and rare; **don't** use shiny metallic gradients or gild everything.
- **Do** earn grandeur through space, restraint, and one strong element; **don't** stack many large display headings.
- **Do** keep functional UI crisp and legible; **don't** let "brushy"/"ornate" intrude on buttons, inputs, and data.
- **Do** use real CJK type with shared DNA where glyphs appear; **don't** use novelty "oriental" display fonts (faux-calligraphy clichés) — the fastest route to kitsch.
- **Do** let red be a surface and a signal; **don't** set body text in red.
- **Do** keep motion smooth and weightless; **don't** add bounce, spring, or aggressive parallax.
- **Do** treat dark mode as home and light mode as a true daytime counterpart; **don't** ship light mode as a washed-out inversion.
