/* @ds-bundle: {"format":3,"namespace":"AburayaDesignSystem_f2407e","components":[],"sourceHashes":{"ui_kits/aburaya/app.jsx":"1626beb8f7e2","ui_kits/aburaya/chrome.jsx":"fbc09e1139f5","ui_kits/aburaya/primitives.jsx":"03fd2d052855","ui_kits/aburaya/screens.jsx":"4fc61bc72cf6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AburayaDesignSystem_f2407e = window.AburayaDesignSystem_f2407e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/aburaya/app.jsx
try { (() => {
/* Aburaya app — controller: theme, auth gate, rail routing, booking modal. */

function App() {
  const [theme, setTheme] = useState("dark");
  const [signedIn, setSignedIn] = useState(false);
  const [active, setActive] = useState("baths");
  const [booking, setBooking] = useState(null);
  const [bName, setBName] = useState("");
  const [bHour, setBHour] = useState("");
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);
  const toggle = () => setTheme(t => t === "dark" ? "light" : "dark");
  if (!signedIn) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "haze"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        top: 18,
        right: 22,
        zIndex: 10
      }
    }, /*#__PURE__*/React.createElement(ThemeToggle, {
      theme: theme,
      onToggle: toggle
    })), /*#__PURE__*/React.createElement(LoginScreen, {
      onEnter: () => setSignedIn(true)
    }), /*#__PURE__*/React.createElement("div", {
      className: "grain"
    }));
  }
  const crumb = RAIL_ITEMS.find(r => r.id === active)?.label || "";
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "haze"
  }), /*#__PURE__*/React.createElement("div", {
    className: "app"
  }, /*#__PURE__*/React.createElement(TopBar, {
    crumb: crumb,
    theme: theme,
    onToggle: toggle,
    right: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: "bell"
    }, "Calls")
  }), /*#__PURE__*/React.createElement(SideRail, {
    active: active,
    onSelect: setActive
  }), /*#__PURE__*/React.createElement("main", {
    className: "main"
  }, active === "baths" ? /*#__PURE__*/React.createElement(BathsView, {
    onOpen: b => {
      setBooking(b);
      setBName("");
      setBHour("");
    }
  }) : /*#__PURE__*/React.createElement(PlaceholderView, {
    label: crumb
  }))), booking && /*#__PURE__*/React.createElement(NorenModal, {
    title: "\u6CB9\u5C4B",
    onClose: () => setBooking(null),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setBooking(null)
    }, "Not yet"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "check",
      onClick: () => setBooking(null)
    }, "Sign & reserve"))
  }, /*#__PURE__*/React.createElement(BookingForm, {
    bath: booking,
    name: bName,
    setName: setBName,
    hour: bHour,
    setHour: setBHour
  })), /*#__PURE__*/React.createElement("div", {
    className: "grain"
  }));
}
function PlaceholderView({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      placeItems: "center",
      height: "100%",
      textAlign: "center",
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-cjk-serif)",
      fontWeight: 700,
      fontSize: 52,
      color: "var(--accent-gold)",
      opacity: .85,
      marginBottom: 14
    }
  }, "\u9593"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "0 0 10px"
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    className: "muted",
    style: {
      margin: 0,
      fontSize: 16,
      lineHeight: 1.65
    }
  }, "Ma \u2014 meaningful interval. This wing of the bath-house is left intentionally quiet in the kit.")));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aburaya/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aburaya/chrome.jsx
try { (() => {
/* Aburaya chrome — TopBar (roofline), SideRail (pillars), NorenModal. */

function TopBar({
  crumb,
  theme,
  onToggle,
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "topbar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "brand"
  }, "\u6CB9\u5C4B ", /*#__PURE__*/React.createElement("span", {
    className: "mark"
  }, "Aburaya")), crumb && /*#__PURE__*/React.createElement("span", {
    className: "crumb"
  }, "\uFF0F ", crumb), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), right, /*#__PURE__*/React.createElement(ThemeToggle, {
    theme: theme,
    onToggle: onToggle
  }));
}
const RAIL_ITEMS = [{
  id: "baths",
  icon: "droplets",
  label: "Baths"
}, {
  id: "guests",
  icon: "users-round",
  label: "Guests"
}, {
  id: "ledger",
  icon: "scroll-text",
  label: "Ledger"
}, {
  id: "stores",
  icon: "package",
  label: "Stores"
}];
function SideRail({
  active,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("nav", {
    className: "rail"
  }, /*#__PURE__*/React.createElement("div", {
    className: "seal",
    title: "Aburaya"
  }, "\u6E6F"), RAIL_ITEMS.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    className: `navbtn ${active === it.id ? "active" : ""}`,
    title: it.label,
    onClick: () => onSelect(it.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 21
  }))), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("button", {
    className: "navbtn",
    title: "Settings"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 21
  })));
}
function NorenModal({
  title,
  onClose,
  children,
  footer
}) {
  useEffect(() => {
    const onKey = e => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return /*#__PURE__*/React.createElement("div", {
    className: "scrim",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    onClick: e => e.stopPropagation(),
    role: "dialog",
    "aria-modal": "true"
  }, /*#__PURE__*/React.createElement("div", {
    className: "noren-cap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ttl"
  }, title)), /*#__PURE__*/React.createElement("div", {
    className: "body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 26px 24px",
      display: "flex",
      gap: 12,
      justifyContent: "flex-end"
    }
  }, footer)));
}
Object.assign(window, {
  TopBar,
  SideRail,
  NorenModal,
  RAIL_ITEMS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aburaya/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aburaya/primitives.jsx
try { (() => {
/* Aburaya primitives — Icon, Button, Field, Lantern, StatusDot, ThemeToggle.
   Icons: Lucide (line icons, rounded joins, medium weight) loaded via UMD in index.html.
   We render <i data-lucide> and re-run lucide.createIcons() after mounts/updates. */

const {
  useEffect,
  useRef,
  useState
} = React;
function Icon({
  name,
  size = 20,
  stroke = 1.75,
  className = "",
  style
}) {
  const ref = useRef(null);
  useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.innerHTML = "";
      const i = document.createElement("i");
      i.setAttribute("data-lucide", name);
      ref.current.appendChild(i);
      window.lucide.createIcons({
        attrs: {
          width: size,
          height: size,
          "stroke-width": stroke
        },
        nameAttr: "data-lucide"
      });
    }
  }, [name, size, stroke]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    className: className,
    style: {
      display: "inline-flex",
      ...style
    },
    "aria-hidden": "true"
  });
}
function Button({
  variant = "primary",
  size,
  icon,
  children,
  onClick,
  type = "button"
}) {
  const cls = ["btn", `btn-${variant}`, size === "sm" ? "btn-sm" : ""].join(" ");
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    className: cls,
    onClick: onClick
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: size === "sm" ? 15 : 17
  }), children);
}
function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text"
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "field"
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "flbl"
  }, label), /*#__PURE__*/React.createElement("input", {
    className: "inp",
    type: type,
    value: value,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value)
  }));
}
function Lantern({
  tone = "red",
  children
}) {
  const cls = tone === "gold" ? "lantern gold" : tone === "quiet" ? "lantern quiet" : "lantern";
  return /*#__PURE__*/React.createElement("span", {
    className: cls
  }, children);
}
function StatusDot({
  state = "on",
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `dot ${state}`
  }, /*#__PURE__*/React.createElement("i", null), children);
}
function ThemeToggle({
  theme,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "tog",
    onClick: onToggle
  }, /*#__PURE__*/React.createElement(Icon, {
    name: theme === "dark" ? "moon-star" : "sun",
    size: 15
  }), theme === "dark" ? "Night" : "Day");
}
Object.assign(window, {
  Icon,
  Button,
  Field,
  Lantern,
  StatusDot,
  ThemeToggle
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aburaya/primitives.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aburaya/screens.jsx
try { (() => {
/* Aburaya screens — Login (grand entrance), BathsView (dense functional view),
   BathCard, BookingForm. */

const BATHS = [{
  id: 6,
  name: "The Herbal Soak",
  jp: "薬湯",
  status: "on",
  temp: "42°",
  note: "Ready · river-herb infusion"
}, {
  id: 7,
  name: "Cedar Steam",
  jp: "檜蒸",
  status: "warn",
  temp: "38°",
  note: "Heating · 12 min to ready"
}, {
  id: 8,
  name: "Lantern Pool",
  jp: "灯湯",
  status: "on",
  temp: "41°",
  note: "Ready · evening lantern light"
}, {
  id: 9,
  name: "The Deep Well",
  jp: "深井",
  status: "busy",
  temp: "40°",
  note: "Occupied · No-Face, party of 1"
}, {
  id: 10,
  name: "Persimmon Bath",
  jp: "柿湯",
  status: "on",
  temp: "39°",
  note: "Ready · autumn fruit steep"
}, {
  id: 11,
  name: "River Spirit Suite",
  jp: "河神",
  status: "warn",
  temp: "37°",
  note: "Draining · stink-spirit cleanse"
}];
function StatCard({
  kicker,
  value,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "tray",
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, kicker), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontVariationSettings: "'opsz' 72,'SOFT' 8",
      fontWeight: 600,
      fontSize: 34,
      lineHeight: 1.1,
      marginTop: 6
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    className: "tert",
    style: {
      fontSize: 12.5,
      marginTop: 2
    }
  }, sub));
}
function BathCard({
  bath,
  onOpen,
  index
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "tray emph clickable",
    onClick: () => onOpen(bath)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-cjk-serif)",
      fontWeight: 700,
      fontSize: 30,
      color: "var(--accent-gold)",
      lineHeight: 1,
      minWidth: 44
    }
  }, bath.jp), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 20
    }
  }, bath.name), /*#__PURE__*/React.createElement(Lantern, {
    tone: "quiet"
  }, "\u2116 ", bath.id)), /*#__PURE__*/React.createElement("p", {
    className: "tert",
    style: {
      margin: "5px 0 0",
      fontSize: 13.5
    }
  }, bath.note)), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      color: "var(--accent-gold)",
      fontSize: 15,
      fontWeight: 600
    }
  }, bath.temp)), /*#__PURE__*/React.createElement("hr", {
    className: "divider",
    style: {
      margin: "16px 0 12px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(StatusDot, {
    state: bath.status
  }, bath.status === "on" ? "Bath ready" : bath.status === "warn" ? "Heating" : "Occupied"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "arrow-right"
  }, "Open")));
}
function BathsView({
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "32px 40px 64px",
      maxWidth: 1100,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 24,
      marginBottom: 28,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, "This evening \xB7 6th day"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "6px 0 0",
      whiteSpace: "nowrap"
    }
  }, "The Baths")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "plus"
  }, "Draw a new bath")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    kicker: "Ready",
    value: "3",
    sub: "of 6 baths"
  }), /*#__PURE__*/React.createElement(StatCard, {
    kicker: "Guests tonight",
    value: "58",
    sub: "14 still bathing"
  }), /*#__PURE__*/React.createElement(StatCard, {
    kicker: "Tokens earned",
    value: "1,204",
    sub: "+18% on yesterday"
  }), /*#__PURE__*/React.createElement(StatCard, {
    kicker: "Avg. soak",
    value: "46m",
    sub: "leisurely, never slothful"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
      gap: 16
    }
  }, BATHS.map((b, i) => /*#__PURE__*/React.createElement(BathCard, {
    key: b.id,
    bath: b,
    index: i,
    onOpen: onOpen
  }))));
}
function BookingForm({
  bath,
  name,
  setName,
  hour,
  setHour
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-cjk-serif)",
      fontWeight: 700,
      fontSize: 30,
      color: "var(--accent-gold)"
    }
  }, bath.jp), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 22
    }
  }, bath.name), /*#__PURE__*/React.createElement("p", {
    className: "tert",
    style: {
      margin: "3px 0 0",
      fontSize: 13
    }
  }, bath.note))), /*#__PURE__*/React.createElement("hr", {
    className: "divider"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Name on the contract",
    value: name,
    onChange: setName,
    placeholder: "\u5343\u5C0B \u2014 your given name"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Hour of arrival",
    value: hour,
    onChange: setHour,
    placeholder: "e.g. 8 in the evening"
  }), /*#__PURE__*/React.createElement("p", {
    className: "muted",
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 1.6
    }
  }, "Sign and the bath is yours for the evening. A gracious welcome awaits \u2014 take your time."));
}
function LoginScreen({
  onEnter
}) {
  const [name, setName] = useState("");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 1,
      height: "100%",
      display: "grid",
      gridTemplateColumns: "1.1fr 0.9fr",
      alignItems: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      padding: "0 72px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker",
    style: {
      marginBottom: 20
    }
  }, "\u6E6F\u5C4B \xB7 the night bath-house"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontVariationSettings: "'opsz' 144,'SOFT' 30",
      fontWeight: 600,
      fontSize: 64,
      lineHeight: 1.08,
      letterSpacing: "-0.01em",
      margin: 0,
      paddingBottom: 6
    }
  }, "Welcome to", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent-gold)"
    }
  }, "Aburaya.")), /*#__PURE__*/React.createElement("p", {
    className: "muted",
    style: {
      fontSize: 18,
      lineHeight: 1.65,
      maxWidth: "44ch",
      marginTop: 28
    }
  }, "Sign your name to the contract and the lanterns will light. A grand old place, an unhurried welcome.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      placeItems: "center",
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "tray emph",
    style: {
      width: "min(380px, 90%)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, "The contract"), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "8px 0 18px",
      fontSize: 24
    }
  }, "Sign in"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Your name",
    value: name,
    onChange: setName,
    placeholder: "\u5343\u5C0B Chihiro"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Seal (password)",
    value: "",
    onChange: () => {},
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    type: "password"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "flame",
    onClick: onEnter
  }, "Light the lanterns"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      justifyContent: "center"
    },
    onClick: onEnter
  }, "Enter as a guest")))));
}
Object.assign(window, {
  BATHS,
  StatCard,
  BathCard,
  BathsView,
  BookingForm,
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aburaya/screens.jsx", error: String((e && e.message) || e) }); }

})();
