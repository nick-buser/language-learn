# Aburaya — UI Kit

A high-fidelity recreation of a representative **Aburaya** product: a bath-house
concierge web app. It exists to demonstrate the design language in real screens —
not as production code. Components are simple, mostly-cosmetic, and reusable.

## Run
Open `index.html`. It loads `../../fonts.css`, `../../colors_and_type.css`, then `app.css`,
then the JSX modules via Babel. Dark (night) is the default; toggle to Day in the top bar.

## Screens / flow
1. **Entrance (login)** — the one grand element: a 64px Fraunces hero + a "contract"
   sign-in tray. `Light the lanterns` or `Enter as a guest` → the app.
2. **The Baths (dashboard)** — the dense functional view: roofline top bar, pillar
   side-rail, stat trays, and a grid of bath cards (lacquer trays) with lantern badges
   and glowing status dots.
3. **Booking (noren modal)** — click any bath → a modal that enters via the noren reveal
   (parts at a center seam), carrying the contract form.
4. Other rail destinations show a quiet **Ma (間)** placeholder by design.

## Files
| File | Contents |
|---|---|
| `index.html` | Mounts React + Babel + Lucide, loads the modules |
| `app.css` | All component styles, built only on semantic tokens |
| `primitives.jsx` | `Icon`, `Button`, `Field`, `Lantern`, `StatusDot`, `ThemeToggle` |
| `chrome.jsx` | `TopBar` (roofline), `SideRail` (pillars), `NorenModal` |
| `screens.jsx` | `LoginScreen`, `BathsView`, `BathCard`, `StatCard`, `BookingForm`, `BATHS` data |
| `app.jsx` | `App` controller: theme, auth gate, rail routing, booking modal |

## Conventions worth lifting
- **Icons** are Lucide (line, rounded joins, ~1.75 stroke), rendered through `<Icon name>`.
- **Elevation** follows the depth principle: glow + gilt keyline at night, warm shadow by day.
- **Motion is transform-only on entrance** (no `opacity:0` keyframes) so content is never
  hidden if animations are paused/frozen (background tabs, capture, print). Glow blooms on
  hover; the noren reveal on the modal. No bounce anywhere.
- Components consume **semantic tokens only** — never raw pigments.
