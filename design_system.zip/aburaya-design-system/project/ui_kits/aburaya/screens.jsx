/* Aburaya screens — Login (grand entrance), BathsView (dense functional view),
   BathCard, BookingForm. */

const BATHS = [
  { id: 6,  name: "The Herbal Soak",    jp: "薬湯",   status: "on",   temp: "42°", note: "Ready · river-herb infusion" },
  { id: 7,  name: "Cedar Steam",        jp: "檜蒸",   status: "warn", temp: "38°", note: "Heating · 12 min to ready" },
  { id: 8,  name: "Lantern Pool",       jp: "灯湯",   status: "on",   temp: "41°", note: "Ready · evening lantern light" },
  { id: 9,  name: "The Deep Well",      jp: "深井",   status: "busy", temp: "40°", note: "Occupied · No-Face, party of 1" },
  { id: 10, name: "Persimmon Bath",     jp: "柿湯",   status: "on",   temp: "39°", note: "Ready · autumn fruit steep" },
  { id: 11, name: "River Spirit Suite", jp: "河神",   status: "warn", temp: "37°", note: "Draining · stink-spirit cleanse" },
];

function StatCard({ kicker, value, sub }) {
  return (
    <div className="tray" style={{ flex: 1, minWidth: 0 }}>
      <p className="kicker">{kicker}</p>
      <div style={{ fontFamily: "var(--font-display)", fontVariationSettings: "'opsz' 72,'SOFT' 8",
        fontWeight: 600, fontSize: 34, lineHeight: 1.1, marginTop: 6 }}>{value}</div>
      <div className="tert" style={{ fontSize: 12.5, marginTop: 2 }}>{sub}</div>
    </div>
  );
}

function BathCard({ bath, onOpen, index }) {
  return (
    <div className="tray emph clickable" onClick={() => onOpen(bath)}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <div style={{ fontFamily: "var(--font-cjk-serif)", fontWeight: 700, fontSize: 30,
          color: "var(--accent-gold)", lineHeight: 1, minWidth: 44 }}>{bath.jp}</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <h3 style={{ margin: 0, fontSize: 20 }}>{bath.name}</h3>
            <Lantern tone="quiet">№ {bath.id}</Lantern>
          </div>
          <p className="tert" style={{ margin: "5px 0 0", fontSize: 13.5 }}>{bath.note}</p>
        </div>
        <div className="mono" style={{ color: "var(--accent-gold)", fontSize: 15, fontWeight: 600 }}>{bath.temp}</div>
      </div>
      <hr className="divider" style={{ margin: "16px 0 12px" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <StatusDot state={bath.status}>
          {bath.status === "on" ? "Bath ready" : bath.status === "warn" ? "Heating" : "Occupied"}
        </StatusDot>
        <Button variant="ghost" size="sm" icon="arrow-right">Open</Button>
      </div>
    </div>
  );
}

function BathsView({ onOpen }) {
  return (
    <div style={{ padding: "32px 40px 64px", maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 24, marginBottom: 28, flexWrap: "wrap" }}>
        <div>
          <p className="kicker">This evening · 6th day</p>
          <h1 style={{ margin: "6px 0 0", whiteSpace: "nowrap" }}>The Baths</h1>
        </div>
        <Button variant="primary" icon="plus">Draw a new bath</Button>
      </div>

      <div style={{ display: "flex", gap: 16, marginBottom: 28 }}>
        <StatCard kicker="Ready" value="3" sub="of 6 baths" />
        <StatCard kicker="Guests tonight" value="58" sub="14 still bathing" />
        <StatCard kicker="Tokens earned" value="1,204" sub="+18% on yesterday" />
        <StatCard kicker="Avg. soak" value="46m" sub="leisurely, never slothful" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
        {BATHS.map((b, i) => <BathCard key={b.id} bath={b} index={i} onOpen={onOpen} />)}
      </div>
    </div>
  );
}

function BookingForm({ bath, name, setName, hour, setHour }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontFamily: "var(--font-cjk-serif)", fontWeight: 700, fontSize: 30, color: "var(--accent-gold)" }}>{bath.jp}</div>
        <div>
          <h3 style={{ margin: 0, fontSize: 22 }}>{bath.name}</h3>
          <p className="tert" style={{ margin: "3px 0 0", fontSize: 13 }}>{bath.note}</p>
        </div>
      </div>
      <hr className="divider" />
      <Field label="Name on the contract" value={name} onChange={setName} placeholder="千尋 — your given name" />
      <Field label="Hour of arrival" value={hour} onChange={setHour} placeholder="e.g. 8 in the evening" />
      <p className="muted" style={{ margin: 0, fontSize: 14, lineHeight: 1.6 }}>
        Sign and the bath is yours for the evening. A gracious welcome awaits — take your time.
      </p>
    </div>
  );
}

function LoginScreen({ onEnter }) {
  const [name, setName] = useState("");
  return (
    <div style={{ position: "relative", zIndex: 1, height: "100%", display: "grid",
      gridTemplateColumns: "1.1fr 0.9fr", alignItems: "stretch" }}>
      {/* grand hero side */}
      <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", padding: "0 72px" }}>
        <p className="kicker" style={{ marginBottom: 20 }}>湯屋 · the night bath-house</p>
        <h1 style={{ fontFamily: "var(--font-display)", fontVariationSettings: "'opsz' 144,'SOFT' 30",
          fontWeight: 600, fontSize: 64, lineHeight: 1.08, letterSpacing: "-0.01em", margin: 0, paddingBottom: 6 }}>
          Welcome to<br /><span style={{ color: "var(--accent-gold)" }}>Aburaya.</span>
        </h1>
        <p className="muted" style={{ fontSize: 18, lineHeight: 1.65, maxWidth: "44ch", marginTop: 28 }}>
          Sign your name to the contract and the lanterns will light. A grand old place, an unhurried welcome.
        </p>
      </div>
      {/* contract panel */}
      <div style={{ display: "grid", placeItems: "center", padding: 40 }}>
        <div className="tray emph" style={{ width: "min(380px, 90%)" }}>
          <p className="kicker">The contract</p>
          <h3 style={{ margin: "8px 0 18px", fontSize: 24 }}>Sign in</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Field label="Your name" value={name} onChange={setName} placeholder="千尋 Chihiro" />
            <Field label="Seal (password)" value="" onChange={() => {}} placeholder="••••••••" type="password" />
            <Button variant="primary" icon="flame" onClick={onEnter}>Light the lanterns</Button>
            <button className="btn btn-ghost" style={{ justifyContent: "center" }} onClick={onEnter}>Enter as a guest</button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { BATHS, StatCard, BathCard, BathsView, BookingForm, LoginScreen });
