/* Aburaya app — controller: theme, auth gate, rail routing, booking modal. */

function App() {
  const [theme, setTheme] = useState("dark");
  const [signedIn, setSignedIn] = useState(false);
  const [active, setActive] = useState("baths");
  const [booking, setBooking] = useState(null);
  const [bName, setBName] = useState("");
  const [bHour, setBHour] = useState("");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  const toggle = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  if (!signedIn) {
    return (
      <React.Fragment>
        <div className="haze"></div>
        <div style={{ position: "fixed", top: 18, right: 22, zIndex: 10 }}>
          <ThemeToggle theme={theme} onToggle={toggle} />
        </div>
        <LoginScreen onEnter={() => setSignedIn(true)} />
        <div className="grain"></div>
      </React.Fragment>
    );
  }

  const crumb = RAIL_ITEMS.find((r) => r.id === active)?.label || "";

  return (
    <React.Fragment>
      <div className="haze"></div>
      <div className="app">
        <TopBar
          crumb={crumb}
          theme={theme}
          onToggle={toggle}
          right={<Button variant="secondary" size="sm" icon="bell">Calls</Button>}
        />
        <SideRail active={active} onSelect={setActive} />
        <main className="main">
          {active === "baths" ? (
            <BathsView onOpen={(b) => { setBooking(b); setBName(""); setBHour(""); }} />
          ) : (
            <PlaceholderView label={crumb} />
          )}
        </main>
      </div>

      {booking && (
        <NorenModal
          title="油屋"
          onClose={() => setBooking(null)}
          footer={
            <React.Fragment>
              <Button variant="ghost" onClick={() => setBooking(null)}>Not yet</Button>
              <Button variant="primary" icon="check" onClick={() => setBooking(null)}>Sign &amp; reserve</Button>
            </React.Fragment>
          }
        >
          <BookingForm bath={booking} name={bName} setName={setBName} hour={bHour} setHour={setBHour} />
        </NorenModal>
      )}

      <div className="grain"></div>
    </React.Fragment>
  );
}

function PlaceholderView({ label }) {
  return (
    <div style={{ display: "grid", placeItems: "center", height: "100%", textAlign: "center", padding: 40 }}>
      <div style={{ maxWidth: 420 }}>
        <div style={{ fontFamily: "var(--font-cjk-serif)", fontWeight: 700, fontSize: 52,
          color: "var(--accent-gold)", opacity: .85, marginBottom: 14 }}>間</div>
        <h2 style={{ margin: "0 0 10px" }}>{label}</h2>
        <p className="muted" style={{ margin: 0, fontSize: 16, lineHeight: 1.65 }}>
          Ma — meaningful interval. This wing of the bath-house is left intentionally quiet in the kit.
        </p>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
