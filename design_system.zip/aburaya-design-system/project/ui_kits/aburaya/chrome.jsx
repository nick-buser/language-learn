/* Aburaya chrome — TopBar (roofline), SideRail (pillars), NorenModal. */

function TopBar({ crumb, theme, onToggle, right }) {
  return (
    <header className="topbar">
      <span className="brand">油屋 <span className="mark">Aburaya</span></span>
      {crumb && <span className="crumb">／ {crumb}</span>}
      <span className="spacer"></span>
      {right}
      <ThemeToggle theme={theme} onToggle={onToggle} />
    </header>
  );
}

const RAIL_ITEMS = [
  { id: "baths", icon: "droplets", label: "Baths" },
  { id: "guests", icon: "users-round", label: "Guests" },
  { id: "ledger", icon: "scroll-text", label: "Ledger" },
  { id: "stores", icon: "package", label: "Stores" },
];

function SideRail({ active, onSelect }) {
  return (
    <nav className="rail">
      <div className="seal" title="Aburaya">湯</div>
      {RAIL_ITEMS.map((it) => (
        <button
          key={it.id}
          className={`navbtn ${active === it.id ? "active" : ""}`}
          title={it.label}
          onClick={() => onSelect(it.id)}
        >
          <Icon name={it.icon} size={21} />
        </button>
      ))}
      <span className="spacer"></span>
      <button className="navbtn" title="Settings">
        <Icon name="settings" size={21} />
      </button>
    </nav>
  );
}

function NorenModal({ title, onClose, children, footer }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div className="noren-cap"><span className="ttl">{title}</span></div>
        <div className="body">{children}</div>
        {footer && <div style={{ padding: "0 26px 24px", display: "flex", gap: 12, justifyContent: "flex-end" }}>{footer}</div>}
      </div>
    </div>
  );
}

Object.assign(window, { TopBar, SideRail, NorenModal, RAIL_ITEMS });
