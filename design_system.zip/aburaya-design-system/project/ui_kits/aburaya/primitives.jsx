/* Aburaya primitives — Icon, Button, Field, Lantern, StatusDot, ThemeToggle.
   Icons: Lucide (line icons, rounded joins, medium weight) loaded via UMD in index.html.
   We render <i data-lucide> and re-run lucide.createIcons() after mounts/updates. */

const { useEffect, useRef, useState } = React;

function Icon({ name, size = 20, stroke = 1.75, className = "", style }) {
  const ref = useRef(null);
  useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.innerHTML = "";
      const i = document.createElement("i");
      i.setAttribute("data-lucide", name);
      ref.current.appendChild(i);
      window.lucide.createIcons({
        attrs: { width: size, height: size, "stroke-width": stroke },
        nameAttr: "data-lucide",
      });
    }
  }, [name, size, stroke]);
  return <span ref={ref} className={className} style={{ display: "inline-flex", ...style }} aria-hidden="true" />;
}

function Button({ variant = "primary", size, icon, children, onClick, type = "button" }) {
  const cls = ["btn", `btn-${variant}`, size === "sm" ? "btn-sm" : ""].join(" ");
  return (
    <button type={type} className={cls} onClick={onClick}>
      {icon && <Icon name={icon} size={size === "sm" ? 15 : 17} />}
      {children}
    </button>
  );
}

function Field({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <label className="field">
      {label && <span className="flbl">{label}</span>}
      <input
        className="inp"
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange && onChange(e.target.value)}
      />
    </label>
  );
}

function Lantern({ tone = "red", children }) {
  const cls = tone === "gold" ? "lantern gold" : tone === "quiet" ? "lantern quiet" : "lantern";
  return <span className={cls}>{children}</span>;
}

function StatusDot({ state = "on", children }) {
  return (
    <span className={`dot ${state}`}>
      <i></i>
      {children}
    </span>
  );
}

function ThemeToggle({ theme, onToggle }) {
  return (
    <button className="tog" onClick={onToggle}>
      <Icon name={theme === "dark" ? "moon-star" : "sun"} size={15} />
      {theme === "dark" ? "Night" : "Day"}
    </button>
  );
}

Object.assign(window, { Icon, Button, Field, Lantern, StatusDot, ThemeToggle });
