# assets/

Brand and imagery assets for Aburaya (logos, illustrations, full-bleed imagery, a bespoke
icon set) belong here.

**Currently empty.** No raster logo, illustration, or photography was provided with the
brief, and the system's guardrails forbid auto-generating brush/SVG "oriental" art that would
read as kitsch. In this build the brand marks are **typographic** — the 湯 seal and the 油屋
noren wordmark, set in Noto Serif JP.

To complete the system, drop in:
- a primary logo / mon (family-crest) mark — radially symmetric, contained in a circle
- 1–2 gouache illustrations for empty states / hero art (warm, matte, flat washes)
- optionally a bespoke crest-geometry icon set (the UI kit currently substitutes Lucide via CDN)
